package uk.ac.brunel.iface;

public interface SyntaxAlgorithmIF{
public double similarity(String str1, String str2);
}
