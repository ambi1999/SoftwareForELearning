/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package uk.ac.brunel.genericlabelmatcher;

/**
 *
 * @author ambi
 */
public class TestConcreteClass1{
    public boolean loadConfiguration(String STR_PATH_CONFIG_FOLDER){
        return false;
    }
    
    public String[][] getMatchedStringPairs(String[] arrayStr1, String[] arrayStr2){
    return null;
    }

}
